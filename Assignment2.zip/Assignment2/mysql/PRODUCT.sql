Drop table if exists PRODUCT;
CREATE TABLE PRODUCT (

    CustomerID int NOT NULL  AUTO_INCREMENT,
    Productname varchar(100) NOT NULL,
    Productnumber  varchar(255) NOT NULL,
    Qty varchar(255) NOT NULL,
    Price double NOT NULL,
    PRIMARY KEY(CustomerID)
);

INSERT into PRODUCT(Productname, Productnumber, Qty, Price)
VALUES
('LapTop', '200100', '2', '3550.43'),
('Iphone', '399234', '3', '2340.3'),
('Glacess', '343400', '5', '23.4'),
('Earphone', '343002', '4', '223.4'),
('Ipad', '238923', '1', '4.34');
