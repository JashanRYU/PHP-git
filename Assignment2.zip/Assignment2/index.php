<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="noindex, nofollow">
    <title>Tasker</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
    <header>
        <a  href="#">
            <img src="./img/logo.jpg" class="logo-img" alt="logo">
        </a>
        <nav>
            <ul>
                <li>Login</li>
                <li>Sign up</li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="top">
            <h1>Organize your work <br>and life.</h1>
            <p>Become focused, organized, and Calm. The World’s #1 task manager and to-do list app.</p>
            <a href="task.php">
                <button type="submit" class="start-todo">Start Now</button>
            </a>
        </div>
        <div class="center">
            <div class="container">
                <img src="./img/ui1.jpg" alt="ui1" class="ui1">
                <img src="./img/ui2.jpg" alt="ui1" class="ui2">
            </div>
        </div>
    </main>
  </body>
</html>
