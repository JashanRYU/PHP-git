<?php

class Database{
    private $connection;

    function __construct() {
        $this->connect_db();
    }

    public function connect_db(){
        $this->connection = mysqli_connect('172.31.22.43','Jashanpreet200513016','OGz6jKJlLm','Jashanpreet200513016');
        if(mysqli_connect_error()){
            die("Database connection failed \n Error: ". mysqli_connect_error() . mysqli_connect_error());
        }
    }

    public function create($task,$comment,$category,$date){
        $sql = "INSERT INTO tasks(task,comments,category,due_date) VALUES ('$task', '$comment', '$category', '$date')";
        $res = mysqli_query($this->connection, $sql);
        if($res){
            return true;
        }else{
            return false;
        }
    }

    public function read($id=null){
        $sql = "SELECT * FROM tasks";
        if($id){
            $sql .= " WHERE id = $id";
        }
        $res = mysqli_query($this->connection, $sql);
        return $res;
    }
    public function sanitize($var){
        $return = mysqli_real_escape_string($this->connection, $var);
        return $return;
    }

    public function deletedata($id){
        $sql = "DELETE FROM tasks WHERE id = $id";
        $res = mysqli_query($this->connection, $sql);
    }

    public function extractor($id)
    {
        $query = "SELECT * FROM tasks WHERE id = '$id'";
        $r = $this->connection->query($query);
        if ($r->num_rows > 0) {
            $r = $r->fetch_assoc();
            return $r;
        }else{
            echo "Record not found";
        }
    }


    public function updateTable($post)
    {
        $task = $this->connection->real_escape_string($_POST['ntask']);
        $comments = $this->connection->real_escape_string($_POST['ncomments']);
        $category = $this->connection->real_escape_string($_POST['ncategory']);
        $id = $this->connection->real_escape_string($_POST['id']);
        if (!empty($id) && !empty($post)) {
            $sql = "UPDATE tasks SET task = '$task', comments = '$comments', category = '$category' WHERE id = '$id'";
            $r = $this->connection->query($sql);
            if ($r == true) {
                header("Updated");
            }else{
                echo "Failed to Edit! Try again Later..";
            }
        }

    }
}

$database = new Database();

