<?php
require_once('database.php');
$res = $database->read();

if(isset($_GET['deleteId']) && !empty($_GET['deleteId'])){
    $deleteId = $_GET['deleteId'];
    $database->deletedata($deleteId);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="noindex, nofollow">
    <title>Your tasks</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
<header>
    <a  href="index.php">
        <img src="./img/logo.jpg" class="logo-img" alt="logo">
    </a>
    <nav>
        <ul>
            <li>Login</li>
            <li>Sign up</li>
        </ul>
    </nav>
</header>
<main>
    <h1><a href="task.php">Your Tasks</a></h1>
    <div class="tasks">
        <?php
        while ($r = mysqli_fetch_assoc($res)){
            ?>
            <a href="task.php?deleteId=<?php echo $r['id']; ?>" class="deleter">O</a>
            <p class="out-1"><?php echo $r['task']?></p><br>
            <p class="out-2"><?php echo $r['comments']?></p><br>
            <div class="tasks-bottom">
                <p class="out-3"><?php echo $r['category']?></p>
                <p class="out-4"><?php echo $r['due_date']?></p>
                <div class="edit-container">
                    <button class="updater"><a href="edit.php?editId=<?php echo $r['id']; ?>">Edit</a></button>
                </div>
            </div>
            <hr>
            <?php
        }
        ?>
    </div>
    <div class="task-bottom">
        <a href="add.php">
            <button type="button" class="btn-add">+</button>
        </a>
    </div>
</main>
</body>
</html>