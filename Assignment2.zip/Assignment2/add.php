<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="noindex, nofollow">
    <title>Add a task</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
<header>
    <a  href="#">
        <img src="./img/logo.jpg" class="logo-img" alt="logo">
    </a>
    <nav>
        <ul>
            <li>Login</li>
            <li>Sign up</li>
        </ul>
    </nav>
</header>
<main>
    <h1>Add a Task</h1>
    <div class="task-adder">
        <form method="post" action="">
            <input type="text" name="task" placeholder="Enter task name" class="input input-task" required><br>
            <input type="text" name="comment" placeholder="Description" class="input input-comment"><br>
            <div class="task-adder-sub">
                <select name="category" class="diff-input input-category" required>
                    <option value="Default">Select a Category</option>
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Biology">Biology</option>
                    <option value="Geography">Geography</option>
                    <option value="Maths">Maths</option>
                </select>
                <input type="date" name="date" placeholder="Date" class="diff-input input-task" required><br>
            </div>
            <a href="task.php">
                <button type="submit" name="submit" class="input-submit">Add</button>
            </a>
        </form>
        <?php
        require_once('database.php');
        if(isset($_POST) & !empty($_POST)){
            $task = $database->sanitize($_POST['task']);
            $comment = $database->sanitize($_POST['comment']);
            $category = $database->sanitize($_POST['category']);
            $date = $database->sanitize($_POST['date']);
            $res = $database->create($task,$comment,$category,$date);
            if($res){
                echo "<p>Task added successfully!</p>";
            }else{
                echo "<p>Task was not added successfully</p>";
            }
        }
        ?>
    </div>

</main>
</body>
</html>